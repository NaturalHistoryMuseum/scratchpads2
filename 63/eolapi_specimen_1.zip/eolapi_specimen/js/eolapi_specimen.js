(function($){
  // EOLAPI object.
  Drupal.eolapi_specimen = Drupal.eolapi_specimen || {};
  Drupal.behaviors.eolapi_specimen = {attach: function(context, settings){
    try {
      $('a[href^="' + Drupal.settings.basePath + 'eol/"]', context).each(function(){
        if($(this).colorbox) {
          $(this).attr('href', $(this).attr('href').replace(/\/nojs(\/|$|\?|&|#)/g, '/ajax$1'));
          $(this).colorbox({rel: 'eolapi'});
        }
      });
    } catch(err) {}
  }};
})(jQuery);