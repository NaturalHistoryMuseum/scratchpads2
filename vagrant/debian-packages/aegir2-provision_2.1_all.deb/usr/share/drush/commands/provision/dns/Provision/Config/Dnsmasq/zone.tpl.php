<?php
  foreach ($hosts as $host => $info) {
    print "addn-hosts={$dns_hostd_path}/{$host}.hosts\n";
  }
?>
