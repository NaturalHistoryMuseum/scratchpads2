<?php

class Provision_Config_Dnsmasq_Zone extends Provision_Config_Dns_Zone {

}
