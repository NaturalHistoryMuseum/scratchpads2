<?php
foreach ($ip_addresses as $server => $ip) {
  print "{$ip}\t    {$this->uri}\n";
 }
?>
